Using double deep q-learning for building trading strategies and integrating technical indicators for better results
